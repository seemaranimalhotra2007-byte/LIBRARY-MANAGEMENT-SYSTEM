package com.cu.library.ui;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Prints the address of the web front end in the Run window after start-up. */
@Component
public class StartupMessage implements CommandLineRunner {

    @Value("${server.port:8080}")
    private int port;

    @Override
    public void run(String... args) {
        System.out.println();
        System.out.println("=================================================");
        System.out.println(" Library Management System is running.");
        System.out.println(" Open in your browser:  http://localhost:" + port);
        System.out.println("=================================================");
    }
}
