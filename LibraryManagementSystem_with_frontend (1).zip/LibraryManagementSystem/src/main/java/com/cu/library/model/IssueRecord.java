package com.cu.library.model;

import java.time.LocalDate;

/** One borrowing transaction: a book issued to a student. returnDate is null until returned. */
public record IssueRecord(int issueId, int bookId, String bookTitle,
                          int studentId, String studentName,
                          LocalDate issueDate, LocalDate dueDate,
                          LocalDate returnDate, double fine) {

    public boolean isReturned() {
        return returnDate != null;
    }
}
