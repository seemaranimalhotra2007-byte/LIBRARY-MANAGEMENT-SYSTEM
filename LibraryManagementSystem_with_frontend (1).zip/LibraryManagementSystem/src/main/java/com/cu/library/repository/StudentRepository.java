package com.cu.library.repository;

import com.cu.library.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/** Spring JDBC data-access class for the students table. */
@Repository
public class StudentRepository {

    private static final String COLUMNS = "SELECT student_id, name, email, department FROM students";

    private static final RowMapper<Student> STUDENT_MAPPER = (rs, rowNum) -> new Student(
            rs.getInt("student_id"),
            rs.getString("name"),
            rs.getString("email"),
            rs.getString("department"));

    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int save(Student s) {
        return jdbcTemplate.update(
                "INSERT INTO students (student_id, name, email, department) VALUES (?, ?, ?, ?)",
                s.id(), s.name(), s.email(), s.department());
    }

    public List<Student> findAll() {
        return jdbcTemplate.query(COLUMNS + " ORDER BY student_id", STUDENT_MAPPER);
    }

    public Optional<Student> findById(int id) {
        return jdbcTemplate.query(COLUMNS + " WHERE student_id = ?", STUDENT_MAPPER, id)
                .stream().findFirst();
    }
}
