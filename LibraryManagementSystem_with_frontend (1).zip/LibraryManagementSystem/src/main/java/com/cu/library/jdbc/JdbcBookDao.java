package com.cu.library.jdbc;

import com.cu.library.model.Book;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * TRADITIONAL JDBC version of the book queries.
 * Here the programmer manually opens the Connection, prepares the PreparedStatement,
 * iterates the ResultSet and closes every resource (try-with-resources) -
 * compare with BookRepository, where Spring's JdbcTemplate does all of this.
 */
@Component
public class JdbcBookDao {

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.password:}")
    private String password;

    public List<Book> findAll() throws SQLException {
        String sql = "SELECT book_id, title, author, available FROM books ORDER BY book_id";
        List<Book> books = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                books.add(map(rs));
            }
        }
        return books;
    }

    public List<Book> searchByTitle(String keyword) throws SQLException {
        String sql = "SELECT book_id, title, author, available FROM books "
                   + "WHERE LOWER(title) LIKE ? ORDER BY book_id";
        List<Book> books = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(url, username, password);
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword.toLowerCase() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    books.add(map(rs));
                }
            }
        }
        return books;
    }

    private Book map(ResultSet rs) throws SQLException {
        return new Book(rs.getInt("book_id"), rs.getString("title"),
                rs.getString("author"), rs.getBoolean("available"));
    }
}
