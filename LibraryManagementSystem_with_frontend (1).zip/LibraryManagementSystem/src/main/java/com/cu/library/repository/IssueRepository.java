package com.cu.library.repository;

import com.cu.library.model.IssueRecord;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/** Spring JDBC data-access class for issue_records (borrowing history). */
@Repository
public class IssueRepository {

    private static final String SELECT =
            "SELECT i.issue_id, i.book_id, b.title, i.student_id, s.name, "
          + "i.issue_date, i.due_date, i.return_date, i.fine "
          + "FROM issue_records i "
          + "JOIN books b ON b.book_id = i.book_id "
          + "JOIN students s ON s.student_id = i.student_id ";

    private static final RowMapper<IssueRecord> ISSUE_MAPPER = (rs, rowNum) -> {
        Date returned = rs.getDate("return_date");
        return new IssueRecord(
                rs.getInt("issue_id"),
                rs.getInt("book_id"),
                rs.getString("title"),
                rs.getInt("student_id"),
                rs.getString("name"),
                rs.getDate("issue_date").toLocalDate(),
                rs.getDate("due_date").toLocalDate(),
                returned == null ? null : returned.toLocalDate(),
                rs.getDouble("fine"));
    };

    private final JdbcTemplate jdbcTemplate;

    public IssueRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int insert(int bookId, int studentId, LocalDate issueDate, LocalDate dueDate) {
        return jdbcTemplate.update(
                "INSERT INTO issue_records (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)",
                bookId, studentId, Date.valueOf(issueDate), Date.valueOf(dueDate));
    }

    /** The currently open (not yet returned) issue of a book, if any. */
    public Optional<IssueRecord> findOpenByBook(int bookId) {
        return jdbcTemplate.query(SELECT + "WHERE i.book_id = ? AND i.return_date IS NULL",
                ISSUE_MAPPER, bookId).stream().findFirst();
    }

    public int markReturned(int issueId, LocalDate returnDate, double fine) {
        return jdbcTemplate.update(
                "UPDATE issue_records SET return_date = ?, fine = ? WHERE issue_id = ?",
                Date.valueOf(returnDate), fine, issueId);
    }

    public List<IssueRecord> findByStudent(int studentId) {
        return jdbcTemplate.query(SELECT + "WHERE i.student_id = ? ORDER BY i.issue_date DESC, i.issue_id DESC",
                ISSUE_MAPPER, studentId);
    }

    public List<IssueRecord> findOverdue(LocalDate today) {
        return jdbcTemplate.query(SELECT + "WHERE i.return_date IS NULL AND i.due_date < ? ORDER BY i.due_date",
                ISSUE_MAPPER, Date.valueOf(today));
    }
}
