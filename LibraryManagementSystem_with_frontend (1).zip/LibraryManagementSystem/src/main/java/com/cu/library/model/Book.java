package com.cu.library.model;

/** A book in the library catalogue (immutable data holder). */
public record Book(int id, String title, String author, boolean available) {
}
