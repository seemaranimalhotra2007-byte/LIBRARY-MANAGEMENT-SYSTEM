package com.cu.library.service;

import com.cu.library.model.Book;
import com.cu.library.model.IssueRecord;
import com.cu.library.model.ReturnReceipt;
import com.cu.library.model.Student;
import com.cu.library.repository.BookRepository;
import com.cu.library.repository.IssueRepository;
import com.cu.library.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Business layer: book issue / return and fine calculation.
 * Methods annotated with @Transactional run as a single database transaction;
 * if a LibraryException (RuntimeException) is thrown, every change is rolled back.
 */
@Service
public class LibraryService {

    private final BookRepository bookRepository;
    private final StudentRepository studentRepository;
    private final IssueRepository issueRepository;

    @Value("${library.loan-days:14}")
    private int loanDays;

    @Value("${library.fine-per-day:2.0}")
    private double finePerDay;

    @Autowired
    public LibraryService(BookRepository bookRepository,
                          StudentRepository studentRepository,
                          IssueRepository issueRepository) {
        this.bookRepository = bookRepository;
        this.studentRepository = studentRepository;
        this.issueRepository = issueRepository;
    }

    // ---------------- Books ----------------
    public void addBook(Book book) {
        if (book.title().isBlank() || book.author().isBlank()) {
            throw new LibraryException("Title and author must not be empty.");
        }
        if (bookRepository.findById(book.id()).isPresent()) {
            throw new LibraryException("A book with ID " + book.id() + " already exists.");
        }
        bookRepository.save(book);
    }

    public List<Book> listBooks() {
        return bookRepository.findAll();
    }

    public List<Book> searchBooks(String keyword) {
        return bookRepository.search(keyword);
    }

    // ---------------- Students ----------------
    public void registerStudent(Student student) {
        if (student.name().isBlank()) {
            throw new LibraryException("Student name must not be empty.");
        }
        if (studentRepository.findById(student.id()).isPresent()) {
            throw new LibraryException("A student with ID " + student.id() + " is already registered.");
        }
        studentRepository.save(student);
    }

    public List<Student> listStudents() {
        return studentRepository.findAll();
    }

    // ---------------- Issue / Return ----------------
    @Transactional
    public LocalDate issueBook(int bookId, int studentId, LocalDate issueDate) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new LibraryException("Book " + bookId + " not found."));
        studentRepository.findById(studentId)
                .orElseThrow(() -> new LibraryException("Student " + studentId + " is not registered."));
        if (!book.available()) {
            throw new LibraryException("'" + book.title() + "' is already issued to another student.");
        }
        LocalDate dueDate = issueDate.plusDays(loanDays);
        issueRepository.insert(bookId, studentId, issueDate, dueDate);
        bookRepository.updateAvailability(bookId, false);
        return dueDate;
    }

    @Transactional
    public ReturnReceipt returnBook(int bookId, LocalDate returnDate) {
        IssueRecord open = issueRepository.findOpenByBook(bookId)
                .orElseThrow(() -> new LibraryException("Book " + bookId + " is not currently issued."));
        if (returnDate.isBefore(open.issueDate())) {
            throw new LibraryException("Return date cannot be before the issue date (" + open.issueDate() + ").");
        }
        long daysLate = Math.max(0, ChronoUnit.DAYS.between(open.dueDate(), returnDate));
        double fine = calculateFine(open.dueDate(), returnDate);
        issueRepository.markReturned(open.issueId(), returnDate, fine);
        bookRepository.updateAvailability(bookId, true);
        return new ReturnReceipt(open.issueId(), open.bookTitle(), open.studentName(),
                open.dueDate(), returnDate, daysLate, fine);
    }

    /** Fine = days late x fine-per-day; zero when returned on or before the due date. */
    public double calculateFine(LocalDate dueDate, LocalDate returnDate) {
        long daysLate = ChronoUnit.DAYS.between(dueDate, returnDate);
        return daysLate > 0 ? daysLate * finePerDay : 0.0;
    }

    // ---------------- Reports ----------------
    public List<IssueRecord> borrowingHistory(int studentId) {
        studentRepository.findById(studentId)
                .orElseThrow(() -> new LibraryException("Student " + studentId + " is not registered."));
        return issueRepository.findByStudent(studentId);
    }

    public List<IssueRecord> overdueBooks(LocalDate today) {
        return issueRepository.findOverdue(today);
    }

    public long daysOverdue(IssueRecord record, LocalDate today) {
        return Math.max(0, ChronoUnit.DAYS.between(record.dueDate(), today));
    }

    public double currentFine(IssueRecord record, LocalDate today) {
        return calculateFine(record.dueDate(), today);
    }

    public int getLoanDays() {
        return loanDays;
    }

    public double getFinePerDay() {
        return finePerDay;
    }
}
