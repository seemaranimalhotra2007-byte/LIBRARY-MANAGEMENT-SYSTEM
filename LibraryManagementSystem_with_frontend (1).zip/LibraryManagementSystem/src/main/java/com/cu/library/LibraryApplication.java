package com.cu.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point of the Library Book Management and Fine Calculation System.
 * @SpringBootApplication enables auto-configuration (DataSource, JdbcTemplate,
 * transaction manager) and component scanning of all sub-packages.
 */
@SpringBootApplication
public class LibraryApplication {
    public static void main(String[] args) {
        SpringApplication.run(LibraryApplication.class, args);
    }
}
