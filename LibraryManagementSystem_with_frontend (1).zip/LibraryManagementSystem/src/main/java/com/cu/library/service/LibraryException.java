package com.cu.library.service;

/** Business-rule violation (book not found, already issued, etc.). Triggers transaction rollback. */
public class LibraryException extends RuntimeException {
    public LibraryException(String message) {
        super(message);
    }
}
