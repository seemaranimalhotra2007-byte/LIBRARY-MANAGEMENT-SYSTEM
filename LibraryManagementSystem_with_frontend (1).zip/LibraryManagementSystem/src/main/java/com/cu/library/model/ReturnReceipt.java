package com.cu.library.model;

import java.time.LocalDate;

/** Result of returning a book, including the calculated overdue fine. */
public record ReturnReceipt(int issueId, String bookTitle, String studentName,
                            LocalDate dueDate, LocalDate returnDate,
                            long daysLate, double fine) {
}
