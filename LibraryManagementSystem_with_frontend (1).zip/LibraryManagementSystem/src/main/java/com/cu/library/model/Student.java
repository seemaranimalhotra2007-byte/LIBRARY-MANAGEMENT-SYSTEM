package com.cu.library.model;

/** A registered library member. */
public record Student(int id, String name, String email, String department) {
}
