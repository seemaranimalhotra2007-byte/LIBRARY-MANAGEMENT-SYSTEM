package com.cu.library.ui;

import com.cu.library.jdbc.JdbcBookDao;
import com.cu.library.model.Book;
import com.cu.library.model.IssueRecord;
import com.cu.library.model.ReturnReceipt;
import com.cu.library.model.Student;
import com.cu.library.service.LibraryException;
import com.cu.library.service.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/** Menu-driven console user interface. Runs automatically after Spring Boot starts. */
@Component
@ConditionalOnProperty(name = "library.console.enabled", havingValue = "true")
public class ConsoleMenu implements CommandLineRunner {

    private final LibraryService service;
    private final JdbcBookDao jdbcBookDao;
    private final Scanner in = new Scanner(System.in);

    @Autowired
    public ConsoleMenu(LibraryService service, JdbcBookDao jdbcBookDao) {
        this.service = service;
        this.jdbcBookDao = jdbcBookDao;
    }

    @Override
    public void run(String... args) {
        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");
            try {
                switch (choice) {
                    case 1 -> addBook();
                    case 2 -> printBooks(service.listBooks());
                    case 3 -> searchBooks();
                    case 4 -> registerStudent();
                    case 5 -> printStudents(service.listStudents());
                    case 6 -> issueBook();
                    case 7 -> returnBook();
                    case 8 -> borrowingHistory();
                    case 9 -> overdueReport();
                    case 10 -> traditionalJdbcDemo();
                    case 0 -> running = false;
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (LibraryException e) {
                System.out.println("ERROR: " + e.getMessage());
            } catch (DataAccessException e) {
                System.out.println("DATABASE ERROR: " + e.getMostSpecificCause().getMessage());
            } catch (SQLException e) {
                System.out.println("DATABASE ERROR: " + e.getMessage());
            }
        }
        System.out.println("Thank you for using the Library Management System. Goodbye!");
    }

    // ---------------- menu actions ----------------
    private void addBook() {
        int id = readInt("Book ID: ");
        String title = readLine("Title: ");
        String author = readLine("Author: ");
        service.addBook(new Book(id, title, author, true));
        System.out.println("Book added successfully.");
    }

    private void searchBooks() {
        String keyword = readLine("Enter title/author keyword: ");
        printBooks(service.searchBooks(keyword));
    }

    private void registerStudent() {
        int id = readInt("Student ID: ");
        String name = readLine("Name: ");
        String email = readLine("Email: ");
        String dept = readLine("Department: ");
        service.registerStudent(new Student(id, name, email, dept));
        System.out.println("Student registered successfully.");
    }

    private void issueBook() {
        int bookId = readInt("Book ID: ");
        int studentId = readInt("Student ID: ");
        LocalDate date = readDate("Issue date (yyyy-MM-dd, Enter = today): ");
        LocalDate due = service.issueBook(bookId, studentId, date);
        System.out.println("Book issued. Due date: " + due
                + " (loan period " + service.getLoanDays() + " days).");
    }

    private void returnBook() {
        int bookId = readInt("Book ID: ");
        LocalDate date = readDate("Return date (yyyy-MM-dd, Enter = today): ");
        ReturnReceipt r = service.returnBook(bookId, date);
        System.out.println("---------------- RETURN RECEIPT ----------------");
        System.out.println("Book      : " + r.bookTitle());
        System.out.println("Student   : " + r.studentName());
        System.out.println("Due date  : " + r.dueDate());
        System.out.println("Returned  : " + r.returnDate());
        System.out.println("Days late : " + r.daysLate());
        System.out.printf("Fine      : Rs. %.2f  (Rs. %.2f per day)%n", r.fine(), service.getFinePerDay());
        System.out.println("------------------------------------------------");
    }

    private void borrowingHistory() {
        int studentId = readInt("Student ID: ");
        List<IssueRecord> list = service.borrowingHistory(studentId);
        if (list.isEmpty()) {
            System.out.println("No borrowing history for this student.");
            return;
        }
        System.out.printf("%-6s %-30s %-12s %-12s %-12s %-8s%n",
                "Issue", "Book", "Issued", "Due", "Returned", "Fine");
        for (IssueRecord r : list) {
            System.out.printf("%-6d %-30s %-12s %-12s %-12s %-8.2f%n",
                    r.issueId(), cut(r.bookTitle(), 30), r.issueDate(), r.dueDate(),
                    r.isReturned() ? r.returnDate().toString() : "NOT RETURNED", r.fine());
        }
    }

    private void overdueReport() {
        LocalDate today = LocalDate.now();
        List<IssueRecord> list = service.overdueBooks(today);
        if (list.isEmpty()) {
            System.out.println("No overdue books today (" + today + ").");
            return;
        }
        System.out.println("Overdue books as on " + today);
        System.out.printf("%-6s %-28s %-18s %-12s %-6s %-8s%n",
                "BookID", "Title", "Student", "Due", "Days", "Fine");
        for (IssueRecord r : list) {
            System.out.printf("%-6d %-28s %-18s %-12s %-6d %-8.2f%n",
                    r.bookId(), cut(r.bookTitle(), 28), cut(r.studentName(), 18), r.dueDate(),
                    service.daysOverdue(r, today), service.currentFine(r, today));
        }
    }

    private void traditionalJdbcDemo() throws SQLException {
        System.out.println("[Traditional JDBC: DriverManager + PreparedStatement + ResultSet]");
        printBooks(jdbcBookDao.findAll());
        String keyword = readLine("Search title with traditional JDBC (keyword): ");
        printBooks(jdbcBookDao.searchByTitle(keyword));
    }

    // ---------------- printing helpers ----------------
    private void printMenu() {
        System.out.println();
        System.out.println("========= LIBRARY MANAGEMENT SYSTEM =========");
        System.out.println(" 1. Add book");
        System.out.println(" 2. View all books");
        System.out.println(" 3. Search books");
        System.out.println(" 4. Register student");
        System.out.println(" 5. View all students");
        System.out.println(" 6. Issue book");
        System.out.println(" 7. Return book (calculate fine)");
        System.out.println(" 8. Student borrowing history");
        System.out.println(" 9. Overdue books report");
        System.out.println("10. Traditional JDBC demo");
        System.out.println(" 0. Exit");
        System.out.println("=============================================");
    }

    private void printBooks(List<Book> books) {
        if (books.isEmpty()) {
            System.out.println("No books found.");
            return;
        }
        System.out.printf("%-6s %-35s %-25s %-10s%n", "ID", "Title", "Author", "Status");
        for (Book b : books) {
            System.out.printf("%-6d %-35s %-25s %-10s%n", b.id(), cut(b.title(), 35),
                    cut(b.author(), 25), b.available() ? "Available" : "Issued");
        }
    }

    private void printStudents(List<Student> students) {
        if (students.isEmpty()) {
            System.out.println("No students registered.");
            return;
        }
        System.out.printf("%-6s %-25s %-28s %-12s%n", "ID", "Name", "Email", "Department");
        for (Student s : students) {
            System.out.printf("%-6d %-25s %-28s %-12s%n", s.id(), cut(s.name(), 25),
                    cut(s.email(), 28), s.department());
        }
    }

    private String cut(String text, int max) {
        if (text == null) {
            return "";
        }
        return text.length() <= max ? text : text.substring(0, max - 1) + "~";
    }

    // ---------------- input helpers ----------------
    private String readLine(String prompt) {
        System.out.print(prompt);
        return in.hasNextLine() ? in.nextLine().trim() : "0";
    }

    private int readInt(String prompt) {
        while (true) {
            String text = readLine(prompt);
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private LocalDate readDate(String prompt) {
        String text = readLine(prompt);
        if (text.isEmpty()) {
            return LocalDate.now();
        }
        try {
            return LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new LibraryException("Invalid date. Use the format yyyy-MM-dd, e.g. 2026-11-15.");
        }
    }
}
