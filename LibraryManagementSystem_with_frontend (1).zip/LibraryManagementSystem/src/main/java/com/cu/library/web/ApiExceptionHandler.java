package com.cu.library.web;

import com.cu.library.service.LibraryException;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLException;
import java.time.format.DateTimeParseException;
import java.util.Map;

/** Converts exceptions into JSON error messages that the front end shows to the user. */
@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(LibraryException.class)
    public ResponseEntity<Map<String, String>> business(LibraryException e) {
        return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
    }

    @ExceptionHandler(DateTimeParseException.class)
    public ResponseEntity<Map<String, String>> badDate(DateTimeParseException e) {
        return ResponseEntity.badRequest().body(Map.of("error", "Invalid date. Use the format yyyy-MM-dd."));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, String>> badInput(HttpMessageNotReadableException e) {
        return ResponseEntity.badRequest().body(Map.of("error", "Invalid input. Please check the values entered."));
    }

    @ExceptionHandler({DataAccessException.class, SQLException.class})
    public ResponseEntity<Map<String, String>> database(Exception e) {
        String msg = e instanceof DataAccessException dae ? dae.getMostSpecificCause().getMessage() : e.getMessage();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "Database error: " + msg));
    }
}
