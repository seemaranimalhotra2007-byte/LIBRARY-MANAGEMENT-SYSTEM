package com.cu.library.web;

import com.cu.library.jdbc.JdbcBookDao;
import com.cu.library.model.Book;
import com.cu.library.model.IssueRecord;
import com.cu.library.model.ReturnReceipt;
import com.cu.library.model.Student;
import com.cu.library.service.LibraryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * REST API used by the browser front end (static/index.html).
 * It only forwards requests to LibraryService - all business rules stay in the service layer.
 */
@RestController
@RequestMapping("/api")
public class LibraryController {

    public record BookRequest(int id, String title, String author) { }
    public record StudentRequest(int id, String name, String email, String department) { }
    public record IssueRequest(int bookId, int studentId, String issueDate) { }
    public record ReturnRequest(int bookId, String returnDate) { }
    public record OverdueRow(int bookId, String bookTitle, String studentName, LocalDate dueDate,
                             long daysOverdue, double fineSoFar) { }

    private final LibraryService service;
    private final JdbcBookDao jdbcBookDao;

    public LibraryController(LibraryService service, JdbcBookDao jdbcBookDao) {
        this.service = service;
        this.jdbcBookDao = jdbcBookDao;
    }

    // ---------------- books ----------------
    @GetMapping("/books")
    public List<Book> books(@RequestParam(required = false) String q) {
        return (q == null || q.isBlank()) ? service.listBooks() : service.searchBooks(q.trim());
    }

    /** Same data, read with traditional JDBC (DriverManager + PreparedStatement + ResultSet). */
    @GetMapping("/books/jdbc")
    public List<Book> booksByJdbc() throws SQLException {
        return jdbcBookDao.findAll();
    }

    @PostMapping("/books")
    public Map<String, String> addBook(@RequestBody BookRequest r) {
        service.addBook(new Book(r.id(), clean(r.title()), clean(r.author()), true));
        return Map.of("message", "Book added successfully.");
    }

    // ---------------- students ----------------
    @GetMapping("/students")
    public List<Student> students() {
        return service.listStudents();
    }

    @PostMapping("/students")
    public Map<String, String> registerStudent(@RequestBody StudentRequest r) {
        service.registerStudent(new Student(r.id(), clean(r.name()), clean(r.email()), clean(r.department())));
        return Map.of("message", "Student registered successfully.");
    }

    @GetMapping("/students/{id}/history")
    public List<IssueRecord> history(@PathVariable int id) {
        return service.borrowingHistory(id);
    }

    // ---------------- issue / return ----------------
    @PostMapping("/issue")
    public Map<String, String> issue(@RequestBody IssueRequest r) {
        LocalDate due = service.issueBook(r.bookId(), r.studentId(), parseDate(r.issueDate()));
        return Map.of(
                "message", "Book issued. Due date: " + due + " (loan period " + service.getLoanDays() + " days).",
                "dueDate", due.toString());
    }

    @PostMapping("/return")
    public ReturnReceipt returnBook(@RequestBody ReturnRequest r) {
        return service.returnBook(r.bookId(), parseDate(r.returnDate()));
    }

    // ---------------- reports ----------------
    @GetMapping("/overdue")
    public List<OverdueRow> overdue() {
        LocalDate today = LocalDate.now();
        return service.overdueBooks(today).stream()
                .map(rec -> new OverdueRow(rec.bookId(), rec.bookTitle(), rec.studentName(), rec.dueDate(),
                        service.daysOverdue(rec, today), service.currentFine(rec, today)))
                .toList();
    }

    @GetMapping("/stats")
    public Map<String, Object> stats() {
        List<Book> books = service.listBooks();
        long available = books.stream().filter(Book::available).count();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("totalBooks", books.size());
        m.put("availableBooks", available);
        m.put("issuedBooks", books.size() - available);
        m.put("students", service.listStudents().size());
        m.put("overdue", service.overdueBooks(LocalDate.now()).size());
        m.put("loanDays", service.getLoanDays());
        m.put("finePerDay", service.getFinePerDay());
        return m;
    }

    // ---------------- helpers ----------------
    private static String clean(String s) {
        return s == null ? "" : s.trim();
    }

    /** Blank date means today; wrong format throws DateTimeParseException (handled as HTTP 400). */
    private static LocalDate parseDate(String s) {
        return (s == null || s.isBlank()) ? LocalDate.now() : LocalDate.parse(s.trim());
    }
}
