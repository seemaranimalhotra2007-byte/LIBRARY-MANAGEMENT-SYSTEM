package com.cu.library.repository;

import com.cu.library.model.Book;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/** Spring JDBC data-access class for the books table (uses JdbcTemplate). */
@Repository
public class BookRepository {

    private static final String COLUMNS = "SELECT book_id, title, author, available FROM books";

    private static final RowMapper<Book> BOOK_MAPPER = (rs, rowNum) -> new Book(
            rs.getInt("book_id"),
            rs.getString("title"),
            rs.getString("author"),
            rs.getBoolean("available"));

    private final JdbcTemplate jdbcTemplate;

    public BookRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int save(Book book) {
        return jdbcTemplate.update(
                "INSERT INTO books (book_id, title, author, available) VALUES (?, ?, ?, ?)",
                book.id(), book.title(), book.author(), book.available());
    }

    public List<Book> findAll() {
        return jdbcTemplate.query(COLUMNS + " ORDER BY book_id", BOOK_MAPPER);
    }

    public Optional<Book> findById(int id) {
        return jdbcTemplate.query(COLUMNS + " WHERE book_id = ?", BOOK_MAPPER, id)
                .stream().findFirst();
    }

    public List<Book> search(String keyword) {
        String pattern = "%" + keyword.toLowerCase() + "%";
        return jdbcTemplate.query(
                COLUMNS + " WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ? ORDER BY book_id",
                BOOK_MAPPER, pattern, pattern);
    }

    public int updateAvailability(int bookId, boolean available) {
        return jdbcTemplate.update("UPDATE books SET available = ? WHERE book_id = ?", available, bookId);
    }
}
